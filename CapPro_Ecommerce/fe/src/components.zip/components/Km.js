import React, { useContext, useEffect, useState } from 'react'
import Ct from './Ct'
import axios from 'axios'
import { Link, useNavigate } from 'react-router-dom'
const Km = () => {
    let obj=useContext(Ct)
    let [prodobj,setProd]=useState("")
    let navigate=useNavigate()
    useEffect(()=>{
        setProd(obj.state.proddet)
        

    },[])
    let add=()=>{
        axios.post("http://localhost:5001/addcart",{'uid':obj.state._id,'pid':prodobj._id,'pimg':prodobj.pimg,'price':prodobj.price,'name':prodobj.name,'qty':1}).then((res)=>{
           
      navigate("/cart")
            
      
    })
}
  return (
    <div>
       {prodobj!=""&& <div className="card">
            <img src={`http://localhost:5001/pimgs/${prodobj.pimg}`} className="card-img-top"/>
            <div className="card-body">
              <h5 className="card-title text-secondary">{prodobj.name.toUpperCase()}</h5>
              <p>Price:{prodobj.price}</p>
              <p>Cat:{prodobj.cat}</p>
              <p>Desc:{prodobj.desc}</p>
              <button onClick={add}>Addcart</button>
            <button><Link to="/">GotoProducts</Link></button>
                  </div>
            

          </div>}
    </div>
  )
}

export default Km