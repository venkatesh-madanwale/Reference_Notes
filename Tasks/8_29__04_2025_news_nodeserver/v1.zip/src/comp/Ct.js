import { createContext } from "react"

let Ct=createContext({})

export default Ct